package com.example.halfsubmission.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.halfsubmission.R
import com.example.halfsubmission.data.Result
import com.example.halfsubmission.databinding.FragmentHomeBinding
import com.example.halfsubmission.ui.adapter.EventAdapter
import com.example.halfsubmission.ui.searchResult.SearchResultActivity
import com.loopj.android.http.AsyncHttpClient.log

/**
 * Fragment untuk menampilkan daftar event yang akan datang dan sudah selesai.
 */
class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var upcomingEventAdapter: EventAdapter
    private lateinit var finishedEventAdapter: EventAdapter
    private var isSearching = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = HomeViewModelFactory.getInstance(requireActivity())
        val viewModel: HomeViewModel by viewModels { factory }

        // Inisialisasi adapter untuk event yang akan datang dan sudah selesai
        upcomingEventAdapter = EventAdapter(
            fragmentSource = "Home",
            onBookmarkClick = { event ->
                if (event.isBookmarked == true) viewModel.deleteNews(event)
                else viewModel.saveNews(event)
            }
        )

        finishedEventAdapter = EventAdapter(
            fragmentSource = "Home",
            onBookmarkClick = { event ->
                if (event.isBookmarked == true) viewModel.deleteNews(event)
                else viewModel.saveNews(event)
            }
        )

        // Atur RecyclerView untuk event yang akan datang
        binding.listUpcomingEvents.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = upcomingEventAdapter
        }

        // Atur RecyclerView untuk event yang sudah selesai
        binding.listFinishedEvents.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = finishedEventAdapter
        }

        // Navigasi ke fragment Upcoming dan Finished
        binding.seeAllUpcomingEventText.setOnClickListener {
            findNavController().navigate(R.id.navigation_Upcoming)
        }
        binding.seeAllFinishedEventText.setOnClickListener {
            findNavController().navigate(R.id.navigation_Finished)
        }

        // Observasi data event yang akan datang
        viewModel.getEvent(1).observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {
                    with(binding){
                        shimmerLayoutUpcoming.visibility = View.VISIBLE
                        listUpcomingEvents.visibility = View.GONE
                        ilustrate.visibility = View.GONE
                    }
                }
                is Result.Error -> {
                    with(binding){
                        shimmerLayoutUpcoming.visibility = View.GONE
                        listUpcomingEvents.visibility = View.GONE
                        ilustrate.visibility = View.GONE
                    }
                    Toast.makeText(context, "Error: ${result.error}", Toast.LENGTH_SHORT).show()
                }
                is Result.Success -> {
                    with(binding){
                        shimmerLayoutUpcoming.visibility = View.GONE
                        if (result.data.isEmpty()) {
                            ilustrate.visibility = View.VISIBLE
                            listUpcomingEvents.visibility = View.GONE
                        } else {
                            ilustrate.visibility = View.GONE
                            listUpcomingEvents.visibility = View.VISIBLE
                            upcomingEventAdapter.submitList(result.data)
                        }
                    }
                }
            }
        }

        // Observasi data event yang sudah selesai
        viewModel.getEvent(0).observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {
                    with(binding){
                        shimmerLayoutFinished.visibility = View.VISIBLE
                        listFinishedEvents.visibility = View.GONE
                    }
                }
                is Result.Error -> {
                    with(binding){
                        shimmerLayoutFinished.visibility = View.GONE
                        listFinishedEvents.visibility = View.VISIBLE
                    }
                    Toast.makeText(context, "Error: ${result.error}", Toast.LENGTH_SHORT).show()
                }
                is Result.Success -> {
                    with(binding){
                        shimmerLayoutFinished.visibility = View.GONE
                        listFinishedEvents.visibility = View.VISIBLE
                    }
                    finishedEventAdapter.submitList(result.data)
                }
            }
        }

        // Atur listener untuk search view
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (isSearching) return false
                isSearching = true

                query?.let {
                    Toast.makeText(requireContext(), "Searching for: $it", Toast.LENGTH_SHORT).show()
                    val intent = Intent(requireContext(), SearchResultActivity::class.java).apply {
                        putExtra("SOURCE_FRAGMENT", "Home")
                        putExtra("query", it)
                    }
                    startActivity(intent)
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean = false
        })
    }

    override fun onResume() {
        super.onResume()
        isSearching = false
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
