package com.example.halfsubmission.ui.adapter

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.halfsubmission.R
import com.example.halfsubmission.data.local.entity.EventEntity
import com.example.halfsubmission.databinding.ItemCardBinding
import com.example.halfsubmission.ui.eventDetail.EventDetailActivity
import com.example.halfsubmission.utils.DateFormatter

/**
 * Adapter untuk menampilkan daftar event.
 *
 * @param fragmentSource Sumber fragment.
 * @param onBookmarkClick Callback saat bookmark diklik.
 */
class EventAdapter(
    private val fragmentSource: String,
    private val onBookmarkClick: (EventEntity) -> Unit
) : ListAdapter<EventEntity, EventAdapter.MyViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding, fragmentSource)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val event = getItem(position)
        holder.bind(event)

        val context = holder.itemView.context
        val ivBookmark = holder.binding.tvbookmark

        // Atur warna bookmark berdasarkan status
        if (event.isBookmarked == true) {
            ivBookmark.setColorFilter(ContextCompat.getColor(context, R.color.red), android.graphics.PorterDuff.Mode.SRC_IN)
            ivBookmark.setOnClickListener {
                ivBookmark.setColorFilter(ContextCompat.getColor(context, R.color.grey), android.graphics.PorterDuff.Mode.SRC_IN)
                onBookmarkClick(event)
            }
        } else {
            ivBookmark.setColorFilter(ContextCompat.getColor(context, R.color.grey), android.graphics.PorterDuff.Mode.SRC_IN)
            ivBookmark.setOnClickListener {
                ivBookmark.setColorFilter(ContextCompat.getColor(context, R.color.red), android.graphics.PorterDuff.Mode.SRC_IN)
                onBookmarkClick(event)
            }
        }
    }

    /**
     * ViewHolder untuk menampilkan item event.
     */
    class MyViewHolder(val binding: ItemCardBinding, private val sourceFragment: String) : RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("CheckResult")
        fun bind(event: EventEntity) {
            with(binding){
                "${event.quota - event.registrants} quota tersedia".also { tvQuota.text = it }
                tvTitle.text = event.name
                tvDate.text = event.beginTime?.let { DateFormatter.formatDate(it) }
                Glide.with(itemView.context).load(event.imageLogo).into(imageView)
            }

            // Navigasi ke detail event saat item diklik
            itemView.setOnClickListener {
                val intent = Intent(itemView.context, EventDetailActivity::class.java).apply {
                    putExtra("EVENT_ID", event.id)
                    putExtra("SOURCE_FRAGMENT", sourceFragment)
                    putExtra("EVENT_UPCOMMING", event.isUpcomming)
                    putExtra("EVENT_BOOKMARKED", event.isBookmarked)
                }
                itemView.context.startActivity(intent)
            }
        }
    }

    companion object {
        /** Callback untuk membandingkan item dalam daftar. */
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<EventEntity>() {
            override fun areItemsTheSame(oldItem: EventEntity, newItem: EventEntity): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: EventEntity, newItem: EventEntity): Boolean {
                return oldItem == newItem
            }
        }
    }
}