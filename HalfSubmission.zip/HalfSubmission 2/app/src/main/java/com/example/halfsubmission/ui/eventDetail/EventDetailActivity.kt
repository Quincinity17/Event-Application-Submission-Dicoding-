package com.example.halfsubmission.ui.eventDetail

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.example.halfsubmission.data.Result
import com.example.halfsubmission.data.local.entity.EventEntity
import com.example.halfsubmission.databinding.ActivityEventDetailBinding
import com.example.halfsubmission.utils.DateFormatter
import com.google.android.material.snackbar.Snackbar
/**
 * Activity untuk menampilkan detail event.
 */
class EventDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEventDetailBinding
    private val viewModel: EventDetailViewModel by viewModels { EventDetailViewModelFactory.getInstance(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEventDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        // Ambil data dari intent
        val eventId = intent.getIntExtra("EVENT_ID", -1)
        val eventBookmark = intent.getBooleanExtra("EVENT_BOOKMARKED", false)
        val eventIsUpcoming = intent.getBooleanExtra("EVENT_UPCOMMING", false)

        if (eventId == -1) {
            Toast.makeText(this, "Invalid Event ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Observasi detail event
        viewModel.getEventDetail(eventId, eventIsUpcoming, eventBookmark).observe(this) { result ->
            when (result) {
                is Result.Loading -> showLoading(true)
                is Result.Success -> {
                    showLoading(false)
                    updateUI(result.data)
                }
                is Result.Error -> {
                    showLoading(false)
                    Snackbar.make(binding.root, "Error: ${result.error}", Snackbar.LENGTH_LONG).show()
                }
            }
        }

        // Tombol kembali
        binding.back.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    /**
     * Memperbarui UI dengan data event.
     *
     * @param eventDetail Data event yang akan ditampilkan.
     */
    private fun updateUI(eventDetail: EventEntity) {
        val eventSource = intent.getStringExtra("SOURCE_FRAGMENT")
        Glide.with(this).load(eventDetail.imageLogo).into(binding.imageViewLogo)

        binding.apply {
            textViewName.text = eventDetail.name
            textViewDescription.text = HtmlCompat.fromHtml(eventDetail.description ?: "", HtmlCompat.FROM_HTML_MODE_LEGACY)
            tvCityName.text = eventDetail.beginTime?.let { DateFormatter.formatDate(it) }
            tvCategory.text = eventDetail.category
            tvOwnerName.text = eventDetail.ownerName
            tvQuota.text = (eventDetail.quota - eventDetail.registrants).toString()
            textViewSource.text = "$eventSource /"

            // Tombol untuk membuka link event
            wideButton.setOnClickListener {
                eventDetail.link?.let { url ->
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                }
            }
        }
    }

    /**
     * Menampilkan atau menyembunyikan loading state.
     *
     * @param isLoading True untuk menampilkan loading, false untuk menyembunyikan.
     */
    private fun showLoading(isLoading: Boolean) {
        binding.apply {
            shimmerLayout.visibility = if (isLoading) View.VISIBLE else View.GONE
            if (isLoading) shimmerLayout.startShimmer() else shimmerLayout.stopShimmer()

            imageViewLogo.visibility = if (isLoading) View.GONE else View.VISIBLE
            eventDetail.visibility = if (isLoading) View.GONE else View.VISIBLE
            textViewDescription.visibility = if (isLoading) View.GONE else View.VISIBLE
            wideButton.visibility = if (isLoading) View.GONE else View.VISIBLE
        }
    }
}
