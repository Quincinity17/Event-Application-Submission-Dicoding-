package com.example.halfsubmission.data.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import com.example.halfsubmission.data.Result
import com.example.halfsubmission.data.local.entity.BookmarkEntity
import com.example.halfsubmission.data.local.room.dao.BookmarkDao

class BookmarkRepository private constructor(
    private val bookmarkDao: BookmarkDao,
    private val eventRepository: EventRepository
) {

    suspend fun insertBookmark(eventId: Int){
        val event = eventRepository.getEventLocalBasedID(eventId)
        event?.let {
            val bookmarkEntity = BookmarkEntity(
                id = it.id,
                name = it.name,
                summary = it.summary,
                description = it.description,
                imageLogo = it.imageLogo,
                mediaCover = it.mediaCover,
                category = it.category,
                ownerName = it.ownerName,
                cityName = it.cityName,
                quota = it.quota,
                registrants = it.registrants,
                beginTime = it.beginTime,
                endTime = it.endTime,
                link = it.link,
                isUpcomming = it.isUpcomming
            )

            bookmarkDao.insertEventBookmark(bookmarkEntity)
        }
    }







    fun getAllBookmarks(): LiveData<Result<List<BookmarkEntity>>> {
        return MediatorLiveData<Result<List<BookmarkEntity>>>().apply {
            value = Result.Loading
            val localData = bookmarkDao.getAllEventsDatabase()
            addSource(localData) { data ->
                value = Result.Success(data)
            }
        }
    }

    suspend fun deleteBookmarkById(event: BookmarkEntity) {
        bookmarkDao.deleteEventBookmark(event)
    }

    companion object {
        @Volatile
        private var instance: BookmarkRepository? = null

        fun getInstance(
            bookmarkDao: BookmarkDao,
            eventRepository: EventRepository
        ): BookmarkRepository =
            instance ?: synchronized(this) {
                instance ?: BookmarkRepository(bookmarkDao, eventRepository)
            }.also { instance = it }
    }
}