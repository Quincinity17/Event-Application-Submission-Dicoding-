package com.example.halfsubmission.ui.upcoming

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.halfsubmission.databinding.FragmentUpcomingBinding
import com.example.halfsubmission.ui.adapter.EventAdapter

/**
 * Fragment untuk menampilkan daftar event yang akan datang.
 */
class UpcomingFragment : Fragment() {
    private var _binding: FragmentUpcomingBinding? = null
    private val binding get() = _binding!!

    private lateinit var upcomingEventAdapter: EventAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUpcomingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = UpcomingViewModelFactory.getInstance(requireContext())
        val viewModel: UpcomingViewModel by viewModels { factory }

        // Inisialisasi adapter untuk menampilkan event yang akan datang
        upcomingEventAdapter = EventAdapter(
            fragmentSource = "Upcoming",
            onBookmarkClick = { event ->
                if (event.isBookmarked == true) viewModel.deleteNews(event)
                else viewModel.saveNews(event)
            }
        )

        // Atur RecyclerView
        binding.listEvent.apply {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = upcomingEventAdapter
        }

        // Observasi data event yang akan datang
        viewModel.getEvent(1).observe(viewLifecycleOwner) { result ->
            when (result) {
                is com.example.halfsubmission.data.Result.Loading -> {
                    binding.apply {
                        ilustrate.visibility = View.GONE
                        shimmerLayout.visibility = View.VISIBLE
                        listEvent.visibility = View.GONE
                    }
                }
                is com.example.halfsubmission.data.Result.Error -> {
                    binding.apply {
                        ilustrate.visibility = View.GONE
                        shimmerLayout.visibility = View.GONE
                        listEvent.visibility = View.GONE
                    }
                    Toast.makeText(context, "Error: ${result.error}", Toast.LENGTH_SHORT).show()
                }
                is com.example.halfsubmission.data.Result.Success -> {
                    binding.apply {
                        shimmerLayout.visibility = View.GONE
                        if (result.data.isEmpty()) {
                            ilustrate.visibility = View.VISIBLE
                            listEvent.visibility = View.GONE
                        } else {
                            ilustrate.visibility = View.GONE
                            listEvent.visibility = View.VISIBLE
                            upcomingEventAdapter.submitList(result.data)
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
