package com.example.halfsubmission.ui.finished

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.halfsubmission.databinding.FragmentFinishedBinding
import com.example.halfsubmission.ui.adapter.EventAdapter

/**
 * Fragment untuk menampilkan daftar event yang sudah selesai.
 */
class FinishedFragment : Fragment() {
    private var _binding: FragmentFinishedBinding? = null
    private val binding get() = _binding!!

    private lateinit var finishedEventAdapter: EventAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFinishedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = FinishedViewModelFactory.getInstance(requireContext())
        val viewModel: FinishedViewModel by viewModels { factory }

        // Inisialisasi adapter untuk menampilkan event
        finishedEventAdapter = EventAdapter(
            fragmentSource = "Finished",
            onBookmarkClick = { event ->
                if (event.isBookmarked == true) {
                    viewModel.deleteNews(event)
                } else {
                    viewModel.saveNews(event)
                }
            }
        )

        // Atur RecyclerView dengan adapter
        binding.listEvent.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = finishedEventAdapter
        }

        // Observasi data event
        viewModel.getEvent(0).observe(viewLifecycleOwner) { result ->
            when (result) {
                is com.example.halfsubmission.data.Result.Loading -> {
                    with(binding){
                        shimmerLayoutFragmentFinished.visibility = View.VISIBLE
                        listEvent.visibility = View.GONE
                    }
                }
                is com.example.halfsubmission.data.Result.Error -> {
                    with(binding){
                        shimmerLayoutFragmentFinished.visibility = View.GONE
                        listEvent.visibility = View.GONE
                    }
                    Toast.makeText(context, "Error: ${result.error}", Toast.LENGTH_SHORT).show()
                }
                is com.example.halfsubmission.data.Result.Success -> {
                    with(binding){
                        shimmerLayoutFragmentFinished.visibility = View.GONE
                        listEvent.visibility = View.VISIBLE
                    }
                    finishedEventAdapter.submitList(result.data) // Masukkan data ke adapter
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
