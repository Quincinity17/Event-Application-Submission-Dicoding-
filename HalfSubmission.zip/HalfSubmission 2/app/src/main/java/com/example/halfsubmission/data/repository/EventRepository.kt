package com.example.halfsubmission.data.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import com.example.halfsubmission.data.Result
import com.example.halfsubmission.data.local.entity.EventEntity
import com.example.halfsubmission.data.local.room.dao.EventDao
import com.example.halfsubmission.data.remote.response.EventResponse
import com.example.halfsubmission.data.remote.retrofit.ApiService
import com.example.halfsubmission.utils.AppExecutors
import com.loopj.android.http.AsyncHttpClient.log
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class EventRepository private constructor(
    private val apiService: ApiService,
    private val eventDao: EventDao,
    private val appExecutors: AppExecutors,
) {
    fun getEvent(active: Int): LiveData<Result<List<EventEntity>>> {
        val result = MediatorLiveData<Result<List<EventEntity>>>()
        result.value = Result.Loading
        val client = apiService.getActiveEvents(active)

        client.enqueue(object : Callback<EventResponse> {
            override fun onResponse(call: Call<EventResponse>, response: Response<EventResponse>) {
                if (response.isSuccessful) {
                    val articles = response.body()?.event
                    val eventList = ArrayList<EventEntity>()

                    appExecutors.diskIO.execute {

                        articles?.forEach { article ->
                            val isBookmarked = eventDao.isEventBookmarked(article.id)
                            val event = EventEntity(
                                id = article.id,
                                name = article.name,
                                summary = article.summary,
                                description = article.description,
                                imageLogo = article.imageLogo,
                                mediaCover = article.mediaCover,
                                category = article.category,
                                ownerName = article.ownerName,
                                cityName = article.cityName,
                                quota = article.quota,
                                registrants = article.registrants,
                                beginTime = article.beginTime,
                                endTime = article.endTime,
                                link = article.link,
                                isBookmarked = isBookmarked,
                                isUpcomming = active == 1
                            )
                            eventList.add(event)
                        }

                        eventDao.deleteAll(active)
                        // Insert new data
                        eventDao.insertEvent(eventList)

                        appExecutors.mainThread.execute {
                            result.addSource(eventDao.getEvents(active)) { newData ->
                                result.value = Result.Success(newData)
                            }
                        }
                    }
                }
            }

            override fun onFailure(call: Call<EventResponse>, t: Throwable) {
                appExecutors.mainThread.execute {
                    result.addSource(eventDao.getEvents(active)) { newData ->
                        result.value = Result.Success(newData)
                    }
                }
            }
        })

        return result
    }

    fun setBookmarkedEvent(event: EventEntity, bookmarkState: Boolean) {
        appExecutors.diskIO.execute {
            event.isBookmarked = bookmarkState
            eventDao.updateEvent(event)
        }
    }

    fun getSearchEvent(query: String): LiveData<List<EventEntity>> {
        return eventDao.searchEvents(query)
    }

    suspend fun getEventLocalBasedID(id: Int): EventEntity? {
        return eventDao.getEventBasedId(id)
    }

    fun getEventDetail(id: Int, isActive:Boolean, eventBookmark:Boolean): LiveData<Result<EventEntity>> {

        val result = MediatorLiveData<Result<EventEntity>>()
        result.value = Result.Loading

        val client = apiService.getEventDetail(id.toString())
        client.enqueue(object : Callback<EventResponse> {
            override fun onResponse(call: Call<EventResponse>, response: Response<EventResponse>) {
                if (response.isSuccessful) {
                    val singleEventItem = response.body()?.singleEvent
                    if (singleEventItem != null) {
                        appExecutors.diskIO.execute {
                            val entity = EventEntity(
                                id = singleEventItem.id,
                                name = singleEventItem.name,
                                summary = singleEventItem.summary,
                                description = singleEventItem.description,
                                imageLogo = singleEventItem.imageLogo,
                                mediaCover = singleEventItem.mediaCover,
                                category = singleEventItem.category,
                                ownerName = singleEventItem.ownerName,
                                cityName = singleEventItem.cityName,
                                quota = singleEventItem.quota,
                                registrants = singleEventItem.registrants,
                                beginTime = singleEventItem.beginTime,
                                endTime = singleEventItem.endTime,
                                link = singleEventItem.link,
                                isBookmarked = eventBookmark,
                                isUpcomming = isActive    
                            )
                            eventDao.insertEvent(listOf(entity))
                        }
                    } else {
                        result.postValue(Result.Error("No event detail found for id=$id"))
                    }
                } else {
                    result.postValue(Result.Error("Failed to fetch event detail from server"))
                }
            }

            override fun onFailure(call: Call<EventResponse>, t: Throwable) {
                result.postValue(Result.Error(t.message.toString()))
            }
        })

        val localData = eventDao.getEventById(id)
        result.addSource(localData) { newData ->
            if (newData != null) {
                result.value = Result.Success(newData)
            } else {
                result.value = Result.Error("Event with id $id not found in local DB")
            }
        }

        return result
    }
    companion object {
        @Volatile
        private var instance: EventRepository? = null

        fun getInstance(
            apiService: ApiService,
            newsDao: EventDao,
            appExecutors: AppExecutors
        ): EventRepository =
            instance ?: synchronized(this) {
                instance ?: EventRepository(apiService, newsDao, appExecutors)
            }.also { instance = it }
    }
}
